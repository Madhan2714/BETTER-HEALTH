This is website designed to help people suffering from mental illness.
The website has feature like virtual therapist and blog


![image](https://github.com/typeerror101/better_help/assets/57269077/6361514e-2aac-4a1d-9b5d-612256ae37ff)
![image](https://github.com/typeerror101/better_help/assets/57269077/5edb996d-9f2e-4989-89c7-dca0e987a238)
![image](https://github.com/typeerror101/better_help/assets/57269077/cfe46022-1b3f-4c80-9946-e7b844da8d8c)
![image](https://github.com/typeerror101/better_help/assets/57269077/7c78856d-5b29-427c-8b7b-7bf0cb2cf8fa)
![image](https://github.com/typeerror101/better_help/assets/57269077/38dc53be-689a-4472-a647-c5b42f1d0422)
![image](https://github.com/typeerror101/better_help/assets/57269077/d03312ff-5a11-4f9f-b399-d5ebafa816ff)
