import React from 'react'

function GetStarted() {
  return (
    <div>GetStarted</div>
  )
}

export default GetStarted